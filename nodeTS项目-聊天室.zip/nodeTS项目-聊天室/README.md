### 安装依赖

```javascript
	1.npm i -g typescript
	2.npm install or npm i
```

### 运行项目

```javascript
	tsc -w
```

[tsconfig.json配置](https://www.tslang.cn/docs/handbook/compiler-options.html)